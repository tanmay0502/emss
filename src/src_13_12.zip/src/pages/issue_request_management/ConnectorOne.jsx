import React from 'react';
import styles from './styles/issue.module.css'

export default function ConnectorOne(){
    return (
        <div className={`${styles.ConnectorOne}`}></div>
    )
}

