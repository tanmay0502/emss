import React, { useState, useEffect } from "react";
import UnitDescription from "./Unit_description"
import { useParams } from "react-router-dom";
import styles from './styles/order.module.css'
import OrderActions from "./OrderActions";

export default function ViewOrderDetails() {
  const OrderID = useParams();
  console.log(OrderID["orderID"], "Orderid")


  const [Order, setOrder] = useState([]);
  const [allOrders, setAllOrders] = useState([]);
  const [isPageLoaded, setIsPageLoaded] = useState(0);
  const [orderById, setOrderById] = useState({});
  const [orderDetailPage, setOrderDetailPage] = useState("-1");
  const UserId = window.sessionStorage.getItem('sessionToken');
  const [flag, setFlag] = useState(0);

  async function getOrders() {
    try {
      const response = await fetch(
        // `${process.env.REACT_APP_API_SERVER}/order/list_orders/${UserId}`,
        `${process.env.REACT_APP_API_SERVER}/order/list_orders/CH01001DEO`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
          mode: "cors"
        }
      );
      const data2 = await response.json();
      setAllOrders(data2["data"])
    } catch (err) {
      console.log(err);
    }
  }
  useEffect(() => {
    if (isPageLoaded == 0) {
      getOrders();
      setIsPageLoaded(1)
    }

  })


  function getId(ID) {
    let temp = ""
    let f = 0;
    for (let i = 0; i < ID.length - 1; i++) {
      if (ID[i] == "_" && ID[i + 1] == "_") {
        f = 1
        break
      }
      else {
        temp = temp + ID[i];
      }
    }
    if (f == 0) {
      temp = temp + ID[ID.length - 2] + ID[ID.length - 1]
    }
    return temp
  }

  useEffect(() => {
    let orderBy_Id = {}
    console.log(allOrders, "allorders")
    if (flag == 0 && allOrders != []) {
      allOrders.map((order) => {

        setFlag(1)
        // const id = getId(order["orderID"])
        const id = (order["orderID"])
        if (id in orderBy_Id) {
          orderBy_Id[id].push(order)
        }
        else {
          orderBy_Id[id] = [order]
        }
        if (id.split(':')[0] == (OrderID['orderID'])) {
          setOrder(Order => [...Order, order]);

        }
      })
    }

    setOrderById(orderBy_Id)
  }, [allOrders])


  return (
    <div className={styles.viewDetailsContainer}>
      {
        flag == 1 &&
        <>
          <UnitDescription Order={Order} OrderID={OrderID['orderID']} />
          <OrderActions Order={Order} />
        </>
      }
    </div >
  );
}