import React from "react";
import { useState, useEffect } from "react";
import "./styles/order.css";

import UnitDescription from "./Unit_description"
import Group from "./Group";
import "../home/styles/Newversion.css";
import { Fragment } from 'react';
import { FaCircle } from 'react-icons/fa'
import { FaKey } from 'react-icons/fa'
import { FaSearch } from "react-icons/fa";
import SomeStats from "../../assets/someStats.svg";
import { ReactComponent as SearchInputElement } from "../../assets/searchInputIcon.svg";
import {
    AiOutlineSortAscending,
    AiOutlineSortDescending,
} from "react-icons/ai";
import ToggleButton from '../../components/ToggleButton';
import { ReactComponent as ArrowLeft } from "../../assets/ArrowLeft.svg";
import { ReactComponent as ArrowRight } from "../../assets/ArrowRight.svg";
import { ReactComponent as ChevronDown } from "../../assets/ChevronDown.svg";
import { ReactComponent as SearchIcon } from "../../assets/search.svg";
import { ReactComponent as SourceIcon } from "../../assets/SourceIcon.svg";

import { ReactComponent as DestIcon } from "../../assets/DestIcon.svg";

export default function WareHouseListUnitTrackerFillAvailability() {
    const [tableFilter, setTableFilter] = useState("");
    const [sortBy, setSortBy] = useState("None");
    const [sortOrder, setSortOrder] = useState("asc");
    const [WareHouse_List, setWareHouse_List] = React.useState([]);
    const [warehouseMapping, setWarehouseMapping] = useState(null)
    const [Details, setDetails] = React.useState([]);
    const [showFill, setShowFill] = useState([]);
    const sortMapping = {
        "None": null,
        "Warehouse ID": "Warehouse ID",
        "Building Type": "BuildingType",
        "Room Type": "Room Type",
    }

    let total_bu_m2 = 0
    let filled_bu_m2 = 0
    let leftout_bu_m2 = 0
    let total_bu_m3 = 0
    let filled_bu_m3 = 0
    let leftout_bu_m3 = 0


    let total_cu_m2 = 0
    let filled_cu_m2 = 0
    let leftout_cu_m2 = 0
    let total_cu_m3 = 0
    let filled_cu_m3 = 0
    let leftout_cu_m3 = 0

    let total_vvpat_m2 = 0
    let filled_vvpat_m2 = 0
    let leftout_vvpat_m2 = 0
    let total_vvpat_m3 = 0
    let filled_vvpat_m3 = 0
    let leftout_vvpat_m3 = 0


    const rightArrow = ">";






    const ActivateWarehouse = async (myId) => {
        if (window.confirm(`Are you sure you want to Activate Warehouse ${myId}? `)) {
            try {

                const response = await fetch(
                    `${process.env.REACT_APP_API_SERVER}/warehouse/activateWarehouse/${myId}`,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        credentials: 'same-origin',
                    }
                )

                const status = response;
                if (status.status == 200) {
                    alert("Warehouse Activated Successfully");
                    // navigate('/session/warehousemanagement');
                    getList();
                }
                else {
                    alert("Deactivation Failed");
                }

            } catch (error) {
                console.log(error);
            }
        }
    }

    const DectivateWarehouse = async (myId) => {
        if (window.confirm(`Are you sure you want to Deactivate Warehouse ${myId}? `)) {
            try {

                const response = await fetch(
                    `${process.env.REACT_APP_API_SERVER}/warehouse/deactivateWarehouse/${myId}`,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        credentials: 'same-origin',
                    }
                )

                const status = response;
                if (status.status == 200) {
                    alert("Warehouse Deactivated Successfully");
                    // window.location.href = '/session/warehousemanagement';
                    getList();
                }
                else {
                    alert("Deactivation Failed");
                }

            } catch (error) {
                console.log(error);
            }
        }
    }

    useEffect(() => {
        var data = Details.filter((elem) => {
            if (tableFilter === "") {
                return true;
            }
            else {
                const filter = tableFilter.toLowerCase();
                return (elem[0].toLowerCase().includes(filter) || elem[1].toLowerCase().includes(filter))
            }
        }).map((val) => {
            return {
                "Warehouse ID": val["warehousebuildingtype"] == 'P' ? <Fragment><span style={{ display: 'flex', justifyContent: 'left', alignItems: 'left', marginLeft: "35%" }}><FaCircle size='0.8em' className='PermaWarehouse' /><span style={{ marginLeft: '10px', marginRight: '10px' }}>{val['warehouseid']}</span>{val['doublelock'] ? <Fragment><FaKey className='keyColor' /><FaKey className='keyColor' /></Fragment> : <FaKey className='keyColor' />}</span></Fragment> : <Fragment><span style={{ display: 'flex', justifyContent: 'left', alignItems: 'left', marginLeft: "35%" }}><FaCircle size='0.8em' className='TempWarehouse' /><span style={{ marginLeft: '10px', marginRight: '10px' }}>{val['warehouseid']}</span>{val['doublelock'] ? <Fragment><FaKey className='keyColor' /><FaKey className='keyColor' /></Fragment> : <FaKey className='keyColor' />}</span></Fragment>,
                "Room Type": warehouseMapping ? warehouseMapping["data"][val["warehousetype"]] : "",
                "Status": <ToggleButton userID={val["warehouseid"]} checked={val["warehousestatus"] === 'A'} onToggle={(e) => {
                    if (val["warehousestatus"] !== "A") {
                        ActivateWarehouse(e)
                    }
                    else {
                        DectivateWarehouse(e)
                    }
                }}
                    customLabels={{
                        "active": "Active",
                        "inactive": "Inactive"
                    }}
                />
            }
        })
        data.sort(function (a, b) {
            if (sortMapping[sortBy] !== null) {
                return a[sortMapping[sortBy]].localeCompare(b[sortMapping[sortBy]])
            }
            else return 0;
        });
        if (sortMapping[sortBy] !== null && sortOrder === 'desc') {
            data.reverse();
        }

        setWareHouse_List(data)
        return () => {
        }
    }, [Details, warehouseMapping])



    async function getList() {
        let userId = sessionStorage.getItem('sessionToken');
        const code = userId.slice(0, 2);
        try {
            const response = await fetch(
                `${process.env.REACT_APP_API_SERVER}/warehouse/listWarehouses`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        "stateCode": code
                    }),
                })

            const data = await response.json();
            setDetails(data["data"]);
        } catch (error) {
            console.log(error);
        }

    }
    useEffect(() => {
        MapWarehouseTypes();
        getList();
    }, [])

    const MapWarehouseTypes = async () => {
        try {
            const response = await fetch(
                `${process.env.REACT_APP_API_SERVER}/warehouse/warehouseTypes`,
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            )
            const types = await response.json();
            // data.map(arr => {
            // 	arr = {...arr, "warehousebuildingtype": }
            // })
            // console.log(data);
            setWarehouseMapping(types);
        } catch (error) {
            console.log(error);
        }
    }
    const FillCapacity = async (id) => {
        if (showFill.includes(id) == true) {
            console.log(showFill.includes(id))
            setShowFill(showFill.filter(item => item !== id));
        }
        else {
            setShowFill([...showFill, id]);
        }
    };


    return (
        // <div className="w-100" style={{ paddingTop: "15px", marginLeft: "-2%" }}>
        <div>
            <div className="flex w-full">
                <div className=" w-3/5">
                    <div className="bg-white p-6 rounded-lg shadow-lg mt-2 w-full">
                        <div
                            className="rounded-t-lg p-2 text-left flex "
                            style={{ backgroundColor: "#84587C" }}
                        >
                            <span className="text-white text-lg ml-5">WareHouses List</span>
                            <div className="w-1/5 d-flex serach_1" style={{ marginLeft: "10%" }} >
                                <SearchIcon />
                                <input
                                    type="text"
                                    placeholder="Search"
                                    style={{ fontSize: "15px" }}
                                />
                            </div>
                            <div className="flex" >
                                <span style={{ minWidth: "max-content", paddingInlineStart: "7.5px", marginTop: "2%" }}>Sort by : &nbsp;</span>
                                <select
                                    style={{ textAlign: "center", outline: "none", background: "transparent", padding: "0px", border: "none" }}
                                    onChange={(e) => setSortBy(e.target.value)}>
                                    <option value={"None"}>Default</option>
                                    <option value={"Warehouse ID"}>Warehouse ID</option>
                                    <option value={"Room Type"}>Room Type</option>
                                    <option value={"Building Type"}>Building Type</option>
                                </select>
                                <ChevronDown />
                                <button className='sortOrderButton' onClick={() => {
                                    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
                                }}>
                                    {sortOrder === 'asc' ? <AiOutlineSortAscending /> : <AiOutlineSortDescending />}
                                </button>
                            </div>
                        </div>
                        <div className="p-2">
                            <table className="w-full mt-4 ">
                                <thead className="HeadRow border-b-2">
                                    <tr>
                                        <th style={{ color: "#f56a3f", padding: "20px" }}>WareHouse ID</th>
                                        <th style={{ color: "#f56a3f", padding: "20px" }}>Room Type</th>
                                        <th style={{ color: "#f56a3f", padding: "20px" }}>Usage Status</th>
                                    </tr>

                                </thead>
                                <tbody>
                                    {WareHouse_List.length > 0 &&
                                        WareHouse_List.map((val, id) => (
                                            <tr onClick={(e) => FillCapacity(id)}>
                                                <td className="text-black text-sm">{val['Warehouse ID']}</td>
                                                <td className="text-black text-sm">{val['Room Type']}</td>
                                                <td className="text-black text-sm">{val['Status']}</td>
                                            </tr>
                                        ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div className="w-2/5">
                    <div className="bg-white p-6 rounded-lg shadow-lg mt-2 w-full m-4" style={{ width: "97%" }}>
                        <p className="text-left font-semibold">Recent Orders <span className="text-gray-400">{rightArrow} Delhi</span></p>
                        <div className="rounded-lg shadow-md mt-5 bg-white">
                            <div
                                className="rounded-t-lg p-2 text-left "
                                style={{ backgroundColor: "#84587C" }}
                            >
                                <span className="text-white text-lg ml-5">Ballot Units</span>
                            </div>
                            <div className="p-2">
                                <table className="w-full mt-4 ">
                                    <tr className="text-red-400 border-b-2 ">
                                        <td>Model</td>
                                        <td>Total</td>
                                        <td>Filled</td>
                                        <td>LeftOut</td>
                                    </tr>
                                    <br />
                                    <tr className=" border-b-2 ">
                                        <td>M2</td>
                                        <td>{total_bu_m2}</td>
                                        <td>{filled_bu_m2}</td>
                                        <td>{leftout_bu_m2}</td>
                                    </tr>
                                    <br />
                                    <tr className=" border-b-2 ">
                                        <td>M3</td>
                                        <td>{total_bu_m3}</td>
                                        <td>{filled_bu_m3}</td>
                                        <td>{leftout_bu_m3}</td>
                                    </tr>
                                    <br />
                                </table>
                            </div>
                        </div>

                        <div className="rounded-lg shadow-md mt-5 bg-white">
                            <div
                                className="rounded-t-lg p-2 text-left "
                                style={{ backgroundColor: "#84587C" }}
                            >
                                <span className="text-white text-lg ml-5">Control Units</span>
                            </div>
                            <div className="p-2">
                                <table className="w-full mt-4 ">
                                    <tr className="text-red-400 border-b-2 ">
                                        <td>Model</td>
                                        <td>Total</td>
                                        <td>Filled</td>
                                        <td>LeftOut</td>
                                    </tr>
                                    <br />
                                    <tr className=" border-b-2 ">
                                        <td>M2</td>
                                        <td>{total_cu_m2}</td>
                                        <td>{filled_cu_m2}</td>
                                        <td>{leftout_cu_m2}</td>
                                    </tr>
                                    <br />
                                    <tr className=" border-b-2 ">
                                        <td>M3</td>
                                        <td>{total_cu_m3}</td>
                                        <td>{filled_cu_m3}</td>
                                        <td>{leftout_cu_m3}</td>
                                    </tr>
                                    <br />

                                </table>

                            </div>
                        </div>
                        <div className="rounded-lg shadow-md mt-5 bg-white">
                            <div
                                className="rounded-t-lg p-2 text-left "
                                style={{ backgroundColor: "#84587C" }}
                            >
                                <span className="text-white text-lg ml-5">VVPAT</span>
                            </div>
                            <div className="p-2">
                                <table className="w-full mt-4 ">
                                    <tr className="text-red-400 border-b-2 ">
                                        <td>Model</td>
                                        <td>Total</td>
                                        <td>Filled</td>
                                        <td>LeftOut</td>
                                    </tr>
                                    <br />
                                    <tr className=" border-b-2 ">
                                        <td>M2</td>
                                        <td>{total_vvpat_m2}</td>
                                        <td>{filled_vvpat_m2}</td>
                                        <td>{leftout_vvpat_m2}</td>
                                    </tr>
                                    <br />
                                    <tr className=" border-b-2 ">
                                        <td>M3</td>
                                        <td>{total_vvpat_m3}</td>
                                        <td>{filled_vvpat_m3}</td>
                                        <td>{leftout_vvpat_m3}</td>
                                    </tr>
                                    <br />
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div >
            {
                showFill.length != 0 &&
                <div className="bg-white p-6 rounded-lg shadow-lg mt-2 w-full m-4" >
                    {
                        showFill.length > 0 &&
                        showFill.map((value, id) => (
                            <div className=" w-100 myCardBody myPadding">
                                <div className="d-flex d-flex-apart">
                                    <Group LabelText="Unit Count" value="AA1122" className="myFont" />
                                </div>

                                <div className="parent_1">
                                    <div className="rounded-lg shadow-md mt-5 bg-white">
                                        <div
                                            className="rounded-t-lg p-2 text-left "
                                            style={{ backgroundColor: "#84587C" }}
                                        >
                                            <span className="text-white text-lg ml-5">Ballot Units</span>
                                        </div>
                                        <div className="p-2">
                                            <table className="w-full mt-4 ">
                                                <tr className="text-red-400 border-b-2 ">
                                                    <td>Model</td>
                                                    <td>Availability</td>
                                                    <td style={{ width: "35%" }}>Fill</td>
                                                </tr>
                                                <br />
                                                <tr className=" border-b-2 ">
                                                    <td>M2</td>
                                                    <td>50</td>
                                                    <td>
                                                        <input className="FILL_INPUT " type="number" id='fill_input_BU_M2' />
                                                    </td>
                                                </tr>
                                                <br />
                                                <tr className=" border-b-2 ">
                                                    <td>M3</td>
                                                    <td >50</td>
                                                    <td>
                                                        <input className="FILL_INPUT " type="number" id='fill_input_BU_M3' />
                                                    </td>
                                                </tr>
                                                <br />

                                            </table>
                                        </div>
                                    </div>

                                    <div className="rounded-lg shadow-md mt-5 bg-white">
                                        <div
                                            className="rounded-t-lg p-2 text-left "
                                            style={{ backgroundColor: "#84587C" }}
                                        >
                                            <span className="text-white text-lg ml-5">Control Units</span>
                                        </div>
                                        <div className="p-2">
                                            <table className="w-full mt-4 ">
                                                <tr className="text-red-400 border-b-2 ">
                                                    <td>Model</td>
                                                    <td>Availability</td>
                                                    <td style={{ width: "35%" }}>Fill</td>
                                                </tr>
                                                <br />
                                                <tr className=" border-b-2 ">
                                                    <td>M2</td>
                                                    <td>50</td>
                                                    <td>
                                                        <input className="FILL_INPUT " type="number" id='fill_input_BU_M2' />
                                                    </td>
                                                </tr>
                                                <br />
                                                <tr className=" border-b-2 ">
                                                    <td>M3</td>
                                                    <td>50</td>
                                                    <td>
                                                        <input className="FILL_INPUT " type="number" id='fill_input_BU_M3' />
                                                    </td>
                                                </tr>
                                                <br />

                                            </table>

                                        </div>
                                    </div>

                                    <div className="rounded-lg shadow-md mt-5 bg-white">
                                        <div
                                            className="rounded-t-lg p-2 text-left "
                                            style={{ backgroundColor: "#84587C" }}
                                        >
                                            <span className="text-white text-lg ml-5">VVPAT</span>
                                        </div>
                                        <div className="p-2">
                                            <table className="w-full mt-4 ">
                                                <tr className="text-red-400 border-b-2 ">
                                                    <td>Model</td>
                                                    <td>Availability</td>
                                                    <td style={{ width: "35%" }}>Fill</td>
                                                </tr>
                                                <br />
                                                <tr className=" border-b-2 ">
                                                    <td>M2</td>
                                                    <td>50</td>
                                                    <td>
                                                        <input className="FILL_INPUT " type="number" id='fill_input_BU_M2' />
                                                    </td>
                                                </tr>
                                                <br />
                                                <tr className=" border-b-2 ">
                                                    <td>M3</td>
                                                    <td>50</td>
                                                    <td>
                                                        <input className="FILL_INPUT " type="number" id='fill_input_BU_M3' />
                                                    </td>
                                                </tr>
                                                <br />

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        ))
                    }
                    <center style={{ marginBottom: '10px' }}>
                        <input
                            type={"submit"}
                            className="mySubmit"
                            style={{ marginTop: "15px" }}
                        ></input>
                    </center>
                </div>
            }
        </div >

    );
}