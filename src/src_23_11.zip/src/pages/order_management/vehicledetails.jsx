import React from "react";
import { useState, useEffect } from "react";
import "./styles/order.css";
import Group from "./Group";
import "../home/styles/Newversion.css";
import { Fragment } from 'react';
import { FaCircle } from 'react-icons/fa'
import { FaKey } from 'react-icons/fa'
import { FaSearch } from "react-icons/fa";
import SomeStats from "../../assets/someStats.svg";
import { ReactComponent as SearchInputElement } from "../../assets/searchInputIcon.svg";
import {
    AiOutlineSortAscending,
    AiOutlineSortDescending,
} from "react-icons/ai";
import ToggleButton from '../../components/ToggleButton';
import { useNavigate } from 'react-router-dom'
import { ReactComponent as ArrowLeft } from "../../assets/ArrowLeft.svg";
import { ReactComponent as ArrowRight } from "../../assets/ArrowRight.svg";
import { ReactComponent as ChevronDown } from "../../assets/ChevronDown.svg";
import { ReactComponent as SearchIcon } from "../../assets/search.svg";
import { ReactComponent as SourceIcon } from "../../assets/SourceIcon.svg";

import { ReactComponent as DestIcon } from "../../assets/DestIcon.svg";

export default function VehicleDetails() {


    const navigate = useNavigate();
    const units = [['M2', 50, 50], ['M2', 50, 50], ['M2', 50, 50], ['M2', 50, 50]]
    const units_1 = [['M2', 50, 50, 50], ['M2', 50, 50, 50]]
    const Unit_length = [1]
    const To_Send = [1, 2, 3]
    const To_Receive = [1, 2, 3]
    const block_1 = [1, 2, 3, 4, 5]

    const [vehicleNumber, setVehicleNumber] = useState();
    const [senderIncharge, setSenderIncharge] = useState();
    const [drivername, setDriverName] = useState();
    const [drivernumber, setDriverNumber] = useState();
    const [escortName, setEcsortName] = useState();
    const [escortnumber, setEscortNumber] = useState();





    // console.log(document.getElementById('formVehicleNumber').value, senderIncharge, drivername, drivernumber, escortName, escortnumber, "Hello")
    return (
        <div>

            <div className="MyContainer">
                <div className="parent_3">
                    <div className="myCard_1 d-flex d-flex-column">
                        <div className="myCardHeader myPadding">Order Details</div>

                        <div className="w-100 myCardBody myPadding">
                            <div className="d-flex d-flex-apart">
                                <Group
                                    LabelText="Order ID"
                                    value="OM12993455"
                                    className="myFont"
                                />
                                <div className="serach d-flex">
                                    <SearchIcon />
                                    <input type="text" placeholder="Search by Reference ID" />
                                </div>
                            </div>

                            <div className="mt-3 mb-3 d-flex d-flex-apart SCROLL_3">

                                {Unit_length.length > 0 &&
                                    Unit_length.map((val) => (

                                        < div className="OrderCard" style={{ width: '91%' }}>
                                            <Group LabelText="Referenced Order ID" value="XYZ/20" />

                                            <div
                                                className="w-100 source_dest d-flex d-flex-apart"
                                                style={{ marginTop: "20px", marginBottom: "15px", width: '100px' }}
                                            >
                                                <div className="d-flex">
                                                    <SourceIcon />
                                                    <Group LabelText="Source" value="Delhi" />
                                                </div>
                                                <div className="d-flex" style={{ marginRight: "-38px" }}>
                                                    <DestIcon />
                                                    <Group
                                                        LabelText="Destination"
                                                        value="Haryana"
                                                        custom={true}
                                                    />
                                                </div>
                                            </div>
                                            <span style={{ fontWeight: "550", fontSize: "18px" }}>
                                                Units Description
                                            </span>
                                            <div className="box2">
                                                <table >
                                                    <thead className="HeadRow" >
                                                        <tr>
                                                            <th style={{ paddingLeft: "25px" }}>Model</th>
                                                            <th style={{ paddingLeft: "25px" }}>Quantity CU</th>
                                                            <th style={{ paddingLeft: "25px" }}>Quantity BU</th>
                                                            <th style={{ paddingLeft: "25px" }}>Quantity VVPAT </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="BodyRow">
                                                        {units_1.length > 0 &&
                                                            units_1.map((value) => (
                                                                <tr>
                                                                    <td className="text-black text-sm">{value[0]}</td>
                                                                    <td className="text-black text-sm">{value[1]}</td>
                                                                    <td className="text-black text-sm">{value[2]}</td>
                                                                    <td className="text-black text-sm">{value[3]}</td>
                                                                </tr>
                                                            ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                            {/* <div className="SCROLL">
                                            <table className="w-100 UnitTable" cellPadding="12px 25px">
                                                <thead className="HeadRow">
                                                    <tr>
                                                        <th>Type</th>
                                                        <th>Quantity</th>
                                                        <th>Model</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="BodyRow">
                                                    {units.length > 0 &&
                                                        units.map((value) => (
                                                            <tr>
                                                                <td className="text-black text-sm">{value[0]}</td>
                                                                <td className="text-black text-sm">{value[1]}</td>
                                                                <td className="text-black text-sm">{value[2]}</td>
                                                            </tr>
                                                        ))}
                                                </tbody>
                                            </table>
                                        </div> */}
                                        </div>
                                    ))}

                            </div>
                            <div className="status-carousel-controls">
                                <button>
                                    <ArrowLeft />
                                </button>
                                <button>
                                    <ArrowRight />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className="myCard_1 d-flex d-flex-column">
                        <div className="myCardHeader myPadding " >Pending Orders</div>
                        <div className="w-100 myCardBody myPadding SCROLL_6">
                            <div style={{ height: "50%" }} >
                                <div className="title"> To Send: </div>
                                <ul className='li_noti'>
                                    {To_Send.length > 0 &&
                                        To_Send.map((val) => (
                                            <li>
                                                <span>
                                                    <span>
                                                        First Randomisation completed in districts - Bhind, Gwalior, Indore, Bhopal
                                                    </span>
                                                    <span>3hrs ago</span>
                                                </span>
                                            </li>
                                        ))}
                                </ul>
                            </div>
                            <div style={{ height: "50%", marginTop: '10px' }} >
                                <div className="title"> To Receive: </div>
                                <ul className='li_noti'>
                                    {To_Receive.length > 0 &&
                                        To_Receive.map((val) => (
                                            <li>
                                                <span>
                                                    <span>
                                                        First Randomisation completed in districts - Bhind, Gwalior, Indore, Bhopal
                                                    </span>
                                                    <span>3hrs ago</span>
                                                </span>
                                            </li>
                                        ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="w3-show-inline-block">
                    <div className="w3-bar">
                        {/* <button className="w3-btn w3-black">Button</button>
                        <button className="w3-btn w3-teal">Button</button>
                        <button className="w3-btn w3-border">Button</button> */}
                        <button
                            type={"submit"}
                            className="Submit w3-btn "
                            style={{ marginTop: "15px" }}
                        // onClick={() => {
                        //     
                        // }}
                        >
                            Assign Users
                        </button>
                        <button
                            type={"submit"}
                            className="Submit w3-btn "
                            style={{ marginTop: "15px" }}
                        // onClick={() => {

                        // }}
                        >
                            Fill Vehicle Details
                        </button>
                    </div>
                </div>

                <div className="myCard d-flex d-flex-column">
                    <div className="myCardHeader myPadding">Vehicle Details</div>
                    <div className="w-100 myCardBody myPadding SCROLL_5">
                        {block_1.length > 0 &&
                            block_1.map((val, id) => (
                                <div className="block ">
                                    <div>
                                        <div className="d-flex d-flex-apart" style={{ marginTop: "18px", marginLeft: "15px" }}>
                                            <Group
                                                LabelText="Order ID"
                                                value="OM12993455"
                                                className="myFont"
                                            />
                                        </div>
                                        <div className="box ">
                                            <div className="d-flex SPAN">
                                                <div className="form_label" style={{ marginRight: "10px", color: "#F56A3F " }}>
                                                    <label htmlFor="">Vehicle Number:</label>
                                                </div>
                                                <div className="form_group">
                                                    <div className="form_input INPUT">
                                                        <input
                                                            required
                                                            id={id}
                                                            type={"text"}
                                                            step="any"
                                                            name=""
                                                            className=""
                                                            placeholder="Vehicle Number"
                                                            onChange={(e) => {
                                                                setVehicleNumber(e)
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="form_label" style={{ marginRight: "10px", color: "#F56A3F " }}>
                                                    <label htmlFor="">Sender Incharge:</label>
                                                </div>
                                                <div className="form_group">
                                                    <div className="form_input INPUT">
                                                        <input
                                                            required
                                                            id="formSenderIncharge"
                                                            type={"text"}
                                                            step="any"
                                                            name=""
                                                            className=""
                                                            placeholder="Sender Incharge"
                                                            onChange={(e) => {
                                                                setSenderIncharge(e)
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex SPAN">
                                                <div className="form_label" style={{ marginLeft: "20px", color: "#F56A3F " }}>
                                                    <label htmlFor="">Driver Name:</label>
                                                </div>
                                                <div className="form_group">
                                                    <div className="form_input INPUT" style={{ marginLeft: "20px" }}>
                                                        <input
                                                            required
                                                            id="formDriverName"
                                                            type={"text"}
                                                            step="any"
                                                            name=""
                                                            className=""
                                                            placeholder="Driver Name"
                                                            onChange={(e) => {
                                                                setDriverName(e)
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="form_label" style={{ marginLeft: "30px", color: "#F56A3F " }}>
                                                    <label htmlFor="">Driver Number:</label>
                                                </div>
                                                <div className="form_group">
                                                    <div className="form_input INPUT" style={{ marginLeft: "20px" }}>
                                                        <input
                                                            required
                                                            id="formDriverNumber"
                                                            type={"number"}
                                                            step="any"
                                                            name=""
                                                            className=""
                                                            placeholder="Driver Number"
                                                            onChange={(e) => {
                                                                setDriverNumber(e)
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex SPAN">
                                                <div className="form_label" style={{ marginRight: "10px", color: "#F56A3F " }}>
                                                    <label htmlFor="">Escort Name:</label>
                                                </div>
                                                <div className="form_group">
                                                    <div className="form_input INPUT">
                                                        <input
                                                            required
                                                            id="formEscortName"
                                                            type={"text"}
                                                            step="any"
                                                            name=""
                                                            className=""
                                                            placeholder="Escort Name"
                                                            onChange={(e) => {
                                                                setEcsortName(e)
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="form_label" style={{ marginLeft: "30px", color: "#F56A3F " }}>
                                                    <label htmlFor="">Escort Contact:</label>
                                                </div>
                                                <div className="form_group">
                                                    <div className="form_input INPUT" style={{ marginLeft: "20px" }}>
                                                        <input
                                                            required
                                                            id="formEscortContact"
                                                            type={"number"}
                                                            step="any"
                                                            name=""
                                                            className=""
                                                            placeholder="Escort Contact"
                                                            onChange={(e) => {
                                                                setEscortNumber(e)
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>

                                            {/* <table className="w-100 UnitTable" cellPadding="12px 25px">
                                        <thead className="HeadRow">
                                            <tr>
                                                <th>Model</th>
                                                <th>Quantity CU</th>
                                                <th>Quantity BU</th>
                                                <th>Quantity VVPAT </th>
                                            </tr>
                                        </thead>
                                        <tbody className="BodyRow">
                                            {units_1.length > 0 &&
                                                units_1.map((value) => (
                                                    <tr>
                                                        <td className="text-black text-sm">{value[0]}</td>
                                                        <td className="text-black text-sm">{value[1]}</td>
                                                        <td className="text-black text-sm">{value[2]}</td>
                                                        <td className="text-black text-sm">{value[3]}</td>
                                                    </tr>
                                                ))}
                                        </tbody>
                                    </table> */}
                                        </div>
                                    </div>
                                    <div>
                                        <div
                                            className="w-100 source_dest d-flex d-flex-apart"
                                            style={{ marginTop: "20px", marginBottom: "15px", width: '100px' }}
                                        >
                                            <div className="d-flex">
                                                <SourceIcon />
                                                <Group LabelText="Source" value="Delhi" />
                                            </div>
                                            <div className="d-flex" style={{ marginRight: "30px" }}>
                                                <DestIcon />
                                                <Group
                                                    LabelText="Destination"
                                                    value="Haryana"
                                                    custom={true}
                                                />
                                            </div>
                                        </div>
                                        <div className="box1">
                                            <table className="w-100" cellPadding="12px 25px">
                                                <thead className="HeadRow">
                                                    <tr>
                                                        <th>Model</th>
                                                        <th>Quantity CU</th>
                                                        <th>Quantity BU</th>
                                                        <th>Quantity VVPAT </th>
                                                    </tr>
                                                </thead>
                                                <tbody className="BodyRow">
                                                    {units_1.length > 0 &&
                                                        units_1.map((value) => (
                                                            <tr>
                                                                <td className="text-black text-sm">{value[0]}</td>
                                                                <td className="text-black text-sm">{value[1]}</td>
                                                                <td className="text-black text-sm">{value[2]}</td>
                                                                <td className="text-black text-sm">{value[3]}</td>
                                                            </tr>
                                                        ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        <center>
                            <input type={"submit"} className="mySubmit">
                            </input>
                        </center>
                    </div>
                </div>
            </div>
            {/* ------------------------------------------------------------------------------------------------------- */}
        </div >
    );
}