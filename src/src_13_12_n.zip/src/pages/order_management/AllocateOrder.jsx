import React from 'react'
import OrderAllocationTable from './OrderAllocationTable'

import styles from './styles/allocateorder.module.css'
import UnitTrackerTable from './UnitTrackerTable'

function AllocateOrder() {
	return (
		<div className={styles.orderAllocationContainer}>
			<div className={styles.optimisedAllocationContainer}>
				<div className={styles.optimisedAllocationHeader}>
					<h4>Optimised Allocation</h4>
				</div>
				<div className={styles.optimisedAllocationTablesContainer}>
					<div className={styles.optimisedAllocationTablesScrollContainer}>
						<div className={styles.optimisedAllocationTables}>
							<OrderAllocationTable />
							<OrderAllocationTable />
							<OrderAllocationTable />
							<OrderAllocationTable />
							<OrderAllocationTable />
							<OrderAllocationTable />
						</div>
					</div>

					<button>
						Submit
					</button>
				</div>
			</div>
		<div className="bg-white p-5 rounded-lg shadow-2xl  w-full m-1 h-fit mb-16 ">
            <p className=" text-lg font-semibold text-center">Unit Tracker</p>

            <div className="rounded-lg shadow-md mt-2 bg-white">
              <div
                className="rounded-t-lg p-2 text-left "
                style={{ backgroundColor: "#84587C" }}
              >
                <span className="text-white text-lg ml-5">Ballot Units</span>
              </div>
              <div className="p-2">
                <table className="w-full mt-4 ">
                  <tr className="text-red-400 border-b-2 ">
                    <td className="">Model</td>
                    <td>Quantity</td>
                  </tr>
                  <br />
                  <tr className=" border-b-2 ">
                    <td>M2</td>
                    <td>2</td>
                  </tr>
                  <br />
                  <tr className=" border-b-2 ">
                    <td>M3</td>
                    <td>2</td>
                  </tr>
                  <br />

                </table>

              </div>
            </div>
            <div className="rounded-lg shadow-md mt-5 bg-white">
              <div
                className="rounded-t-lg p-2 text-left "
                style={{ backgroundColor: "#84587C" }}
              >
                <span className="text-white text-lg ml-5">Control Units</span>
              </div>
              <div className="p-2">
                <table className="w-full mt-4 ">
                  <tr className="text-red-400 border-b-2 ">
                    <td className="">Model</td>
                    <td>Quantity</td>
                  </tr>
                  <br />
                  <tr className=" border-b-2 ">
                    <td>M2</td>
                    <td>2</td>
                  </tr>
                  <br />
                  <tr className=" border-b-2 ">
                    <td>M3</td>
                    <td>2</td>
                  </tr>
                  <br />

                </table>

              </div>
            </div>
            <div className="rounded-lg shadow-md mt-5 bg-white">
              <div
                className="rounded-t-lg p-2 text-left "
                style={{ backgroundColor: "#84587C" }}
              >
                <span className="text-white text-lg ml-5">VVPAT</span>
              </div>
              <div className="p-2">
                <table className="w-full mt-4 ">
                  <tr className="text-red-400 border-b-2 ">
                    <td className="">Model</td>
                    <td>Quantity</td>
                  </tr>
                  <br />
                  <tr className=" border-b-2 ">
                    <td>M2</td>
                    <td>2</td>
                  </tr>
                  <br />
                  <tr className=" border-b-2 ">
                    <td>M3</td>
                    <td>2</td>
                  </tr>
                  <br />

                </table>

              </div>
            </div>


          </div>
        </div>
		
	)
}

export default AllocateOrder