import React from 'react'

function SelectOrderType() {
  return (
    <div className='create-order-page'>
        Select Order Type
    </div>
  )
}

export default SelectOrderType